// Copyright Epic Games, Inc. All Rights Reserved.

#include "Roles/LiveLinkLocatorTypes.h"
