#pragma once
#include "CoreMinimal.h"

// Declare it once in a header
DECLARE_LOG_CATEGORY_EXTERN(LogVMCLiveLink, Log, All);
