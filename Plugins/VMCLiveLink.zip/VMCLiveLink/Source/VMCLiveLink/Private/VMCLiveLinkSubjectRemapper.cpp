﻿#include "VMCLiveLinkSubjectRemapper.h"

#include "LiveLinkTypes.h"
#include "Roles/LiveLinkAnimationTypes.h"

class FVMCLiveLinkSubjectRemapperWorker final : public ILiveLinkSubjectRemapperWorker
{
public:
	FVMCLiveLinkSubjectRemapperWorker(const TMap<FName, FName>& InBoneMap, bool bInKeepUnmapped)
		: BoneMap(InBoneMap), bKeepUnmapped(bInKeepUnmapped) {
	}

	virtual void RemapStaticData(FLiveLinkStaticDataStruct& InOutStatic) override
	{
		if (FLiveLinkSkeletonStaticData* Skel = InOutStatic.Cast<FLiveLinkSkeletonStaticData>())
		{
			for (FName& BoneName : Skel->BoneNames)
			{
				if (const FName* NewName = BoneMap.Find(BoneName))
				{
					BoneName = *NewName;
				}
				else if (!bKeepUnmapped)
				{
					BoneName = NAME_None;
				}
			}
		}
	}

	virtual void RemapFrameData(const FLiveLinkStaticDataStruct& InStaticData,
		FLiveLinkFrameDataStruct& InOutFrameData) override
	{
		// Frames remain aligned with (possibly renamed) static data.
		(void)InStaticData; (void)InOutFrameData;
	}

private:
	const TMap<FName, FName> BoneMap;
	const bool bKeepUnmapped = true;
};

ULiveLinkSubjectRemapper::FWorkerSharedPtr
UVMCLiveLinkSubjectRemapper::CreateWorker()
{
	const bool bKeepUnmappedLocal = true;
	return MakeShared<FVMCLiveLinkSubjectRemapperWorker>(BoneNameMap, bKeepUnmappedLocal);
}

void UVMCLiveLinkSubjectRemapper::SeedCommonMappings()
{
	if (BoneNameMap.IsEmpty())
	{
		BoneNameMap.Add("root", "root");
		BoneNameMap.Add("hips", "pelvis");
		BoneNameMap.Add("spine", "spine_01");
		BoneNameMap.Add("chest", "spine_02");
		BoneNameMap.Add("upperChest", "spine_03");
		BoneNameMap.Add("neck", "neck_01");
		BoneNameMap.Add("head", "head");

		BoneNameMap.Add("leftShoulder", "clavicle_l");
		BoneNameMap.Add("leftUpperArm", "upperarm_l");
		BoneNameMap.Add("leftLowerArm", "lowerarm_l");
		BoneNameMap.Add("leftHand", "hand_l");

		BoneNameMap.Add("rightShoulder", "clavicle_r");
		BoneNameMap.Add("rightUpperArm", "upperarm_r");
		BoneNameMap.Add("rightLowerArm", "lowerarm_r");
		BoneNameMap.Add("rightHand", "hand_r");

		BoneNameMap.Add("leftUpperLeg", "thigh_l");
		BoneNameMap.Add("leftLowerLeg", "calf_l");
		BoneNameMap.Add("leftFoot", "foot_l");

		BoneNameMap.Add("rightUpperLeg", "thigh_r");
		BoneNameMap.Add("rightLowerLeg", "calf_r");
		BoneNameMap.Add("rightFoot", "foot_r");

		BoneNameMap.Add("leftThumbProximal", "thumb_01_l");
		BoneNameMap.Add("leftThumbIntermediate", "thumb_02_l");
		BoneNameMap.Add("leftThumbDistal", "thumb_03_l");
		BoneNameMap.Add("rightThumbProximal", "thumb_01_r");
		BoneNameMap.Add("rightThumbIntermediate", "thumb_02_r");
		BoneNameMap.Add("rightThumbDistal", "thumb_03_r");
	}
}
