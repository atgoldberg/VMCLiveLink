﻿#include "VMCAxisUnitsTranslator.h"

#include "LiveLinkTypes.h"
#include "Roles/LiveLinkAnimationTypes.h"
#include "Math/Quat.h"
#include "Math/UnrealMathUtility.h"

class FVMCAxisUnitsTranslatorWorker final : public ILiveLinkFrameTranslatorWorker
{
public:
	FVMCAxisUnitsTranslatorWorker(float InUnitsScale, bool bInYaw90, bool bInMirrorY)
		: UnitsScale(InUnitsScale)
		, bYaw90(bInYaw90)
		, bMirrorY(bInMirrorY)
	{
	}

	virtual bool Translate(const FLiveLinkStaticDataStruct& InStatic,
		const FLiveLinkFrameDataStruct& InFrame,
		FLiveLinkSubjectFrameData& Out) const override
	{
		const FLiveLinkAnimationFrameData* InAnim = InFrame.Cast<FLiveLinkAnimationFrameData>();
		if (!InAnim) return false;

		// Frame: init then cast
		Out.FrameData.InitializeWith(FLiveLinkAnimationFrameData::StaticStruct());
		FLiveLinkAnimationFrameData& OutAnim = *Out.FrameData.Cast<FLiveLinkAnimationFrameData>();
		OutAnim = *InAnim;

		// Static (if present): init then cast
		if (const FLiveLinkAnimationStaticData* InAnimStatic = InStatic.Cast<FLiveLinkAnimationStaticData>())
		{
			Out.StaticData.InitializeWith(FLiveLinkAnimationStaticData::StaticStruct());
			FLiveLinkAnimationStaticData& OutAnimStatic = *Out.StaticData.Cast<FLiveLinkAnimationStaticData>();
			OutAnimStatic = *InAnimStatic;
		}

		const int32 Num = OutAnim.Transforms.Num();
		const FQuat YawQ(FVector::UpVector, FMath::DegreesToRadians(90.f));

		for (int32 i = 0; i < Num; ++i)
		{
			FTransform& T = OutAnim.Transforms[i];

			// 1) Units
			T.SetLocation(T.GetLocation() * UnitsScale);

			// 2) Optional Y-mirror to address handedness
			if (bMirrorY)
			{
				FVector P = T.GetLocation();
				P.Y *= -1.f;
				T.SetLocation(P);

				FRotator R = T.GetRotation().Rotator();
				R.Yaw *= -1.f;
				R.Roll *= -1.f;
				T.SetRotation(FQuat(R));
			}

			// 3) Unity +Z forward -> UE +X forward (add +90° yaw)
			if (bYaw90)
			{
				T.SetLocation(YawQ.RotateVector(T.GetLocation()));
				T.SetRotation((YawQ * T.GetRotation()).GetNormalized());
			}
		}

		return true;
	}

private:
	const float UnitsScale;
	const bool  bYaw90;
	const bool  bMirrorY;
};

ULiveLinkFrameTranslator::FWorkerSharedPtr
UVMCAxisUnitsTranslator::CreateWorker(TSubclassOf<ULiveLinkRole> /*InRole*/) const
{
	return MakeShared<FVMCAxisUnitsTranslatorWorker>(UnitsScale, bRotateUnityForwardToUE, bMirrorY);
}
