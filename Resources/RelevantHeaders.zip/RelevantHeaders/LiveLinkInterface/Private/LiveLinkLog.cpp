// Copyright Epic Games, Inc. All Rights Reserved.

#include "LiveLinkLog.h"

TUniquePtr<FLiveLinkLog> FLiveLinkLog::Instance;
