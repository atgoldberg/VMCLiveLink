﻿#include "VMCLiveLinkSource.h"
#include "VMCLog.h"

// Live Link
#include "ILiveLinkClient.h"
#include "LiveLinkTypes.h"
#include "Roles/LiveLinkAnimationRole.h"
#include "Roles/LiveLinkAnimationTypes.h"

// OSC (cpp-only)
#include "OSCServer.h"
#include "OSCMessage.h"
#include "OSCTypes.h"

// Math
#include "Math/RotationMatrix.h"

// ---------------- Utils: OSC argument reading (UE5.6) ----------------

static bool ReadStringFloat7(const FOSCMessage& Msg, FString& OutName,
    float& px, float& py, float& pz,
    float& qx, float& qy, float& qz, float& qw)
{
    const TArray<UE::OSC::FOSCData>& A = Msg.GetArgumentsChecked();
    if (A.Num() != 8) return false;
    OutName = A[0].GetString();
    px = A[1].GetFloat(); py = A[2].GetFloat(); pz = A[3].GetFloat();
    qx = A[4].GetFloat(); qy = A[5].GetFloat(); qz = A[6].GetFloat(); qw = A[7].GetFloat();
    return true;
}

static bool ReadFloat7(const FOSCMessage& Msg,
    float& px, float& py, float& pz,
    float& qx, float& qy, float& qz, float& qw)
{
    const TArray<UE::OSC::FOSCData>& A = Msg.GetArgumentsChecked();
    if (A.Num() != 7) return false;
    px = A[0].GetFloat(); py = A[1].GetFloat(); pz = A[2].GetFloat();
    qx = A[3].GetFloat(); qy = A[4].GetFloat(); qz = A[5].GetFloat(); qw = A[6].GetFloat();
    return true;
}

// ---------------- Ctors & status ----------------

FVMCLiveLinkSource::FVMCLiveLinkSource(const FString& InSourceName)
    : SourceName(InSourceName), ListenPort(39539), bUnityToUE(true), bMetersToCm(true), YawOffsetDeg(0.f)
{
}

FVMCLiveLinkSource::FVMCLiveLinkSource(const FString& InSourceName, int32 InPort)
    : SourceName(InSourceName), ListenPort(InPort), bUnityToUE(true), bMetersToCm(true), YawOffsetDeg(0.f)
{
}

FVMCLiveLinkSource::FVMCLiveLinkSource(const FString& InSourceName, int32 InPort, bool bInUnityToUE, bool bInMetersToCm, float InYawDeg)
    : SourceName(InSourceName), ListenPort(InPort), bUnityToUE(bInUnityToUE), bMetersToCm(bInMetersToCm), YawOffsetDeg(InYawDeg)
{
}

void FVMCLiveLinkSource::ReceiveClient(ILiveLinkClient* InClient, FGuid InSourceGuid)
{
    Client = InClient;
    SourceGuid = InSourceGuid;
    bIsValid = StartOSC();

    UE_LOG(LogVMCLiveLink, Log, TEXT("VMC source '%s' listening on %d (valid=%d, unity2ue=%d, m_to_cm=%d, yaw=%.1f)"),
        *SourceName, ListenPort, bIsValid ? 1 : 0, bUnityToUE ? 1 : 0, bMetersToCm ? 1 : 0, YawOffsetDeg);
}

bool FVMCLiveLinkSource::RequestSourceShutdown()
{
    StopOSC();
    bIsValid = false;
    Client = nullptr;
    return true;
}

FText FVMCLiveLinkSource::GetSourceStatus() const
{
    const bool bReady = bIsValid && bStaticSent;
    return bIsValid
        ? (bReady
            ? NSLOCTEXT("VMCLiveLink", "Status_Receiving", "Receiving data")
            : NSLOCTEXT("VMCLiveLink", "Status_Waiting", "Waiting for first frame"))
        : NSLOCTEXT("VMCLiveLink", "Status_Stopped", "Stopped");
}

// ---------------- OSC lifecycle ----------------

bool FVMCLiveLinkSource::StartOSC()
{
    if (OscServer.IsValid())
        return true;

    OscServer = TStrongObjectPtr<UOSCServer>(NewObject<UOSCServer>());
    if (!OscServer.IsValid())
    {
        UE_LOG(LogVMCLiveLink, Error, TEXT("Failed to create UOSCServer"));
        return false;
    }

    OscServer->OnOscMessageReceivedNative.AddRaw(this, &FVMCLiveLinkSource::OnOscMessageReceived);

    if (!OscServer->SetAddress(TEXT("0.0.0.0"), (uint16)ListenPort))
    {
        UE_LOG(LogVMCLiveLink, Error, TEXT("UOSCServer SetAddress failed for port %d"), ListenPort);
        OscServer->OnOscMessageReceivedNative.RemoveAll(this);
        OscServer.Reset();
        return false;
    }

    OscServer->Listen();
    return true;
}

void FVMCLiveLinkSource::StopOSC()
{
    if (OscServer.IsValid())
    {
        OscServer->OnOscMessageReceivedNative.RemoveAll(this);
        OscServer->Stop();
        OscServer.Reset();
    }
}

// ---------------- Unity→UE change-of-basis (with yaw) ----------------

// Permutation C: Unity (X right, Y up, Z fwd) -> UE (X fwd, Y right, Z up)
// i.e. (x',y',z') = (z, x, y)
static FMatrix MakePermutationC()
{
    return FMatrix(
        FPlane(0, 0, 1, 0), // row 0
        FPlane(1, 0, 0, 0), // row 1
        FPlane(0, 1, 0, 0), // row 2
        FPlane(0, 0, 0, 1)
    );
}

// Build B = Rz(yaw) * C  (fold user yaw into the basis; no visible spin at rest)
FMatrix FVMCLiveLinkSource::BuildUnityToUEBasis(float YawDeg)
{
    // Yaw is rotation about UE Z
    const FMatrix R = FRotationMatrix(FRotator(0.f, YawDeg, 0.f));
    const FMatrix C = FMatrix(
        FPlane(0, 0, 1, 0),  // Unity→UE permutation rows
        FPlane(1, 0, 0, 0),
        FPlane(0, 1, 0, 0),
        FPlane(0, 0, 0, 1)
    );
    return R * C; // B = Rz(yaw) * C
}

FVector FVMCLiveLinkSource::MapPos_UnityToUE(const FVector& U, bool bMetersToCm, float YawDeg)
{
    const FMatrix B = BuildUnityToUEBasis(YawDeg);
    const float S = bMetersToCm ? 100.f : 1.f;
    return B.TransformVector(U) * S; // rotation only
}

// Proper change-of-basis for rotations: Re = B * Ru * B^T
FQuat FVMCLiveLinkSource::ConvertQuat_UnityToUE(const FQuat& Qu, float YawDeg)
{
    // Unity rotation matrix Mu from quaternion axes
    const FVector Xu = Qu.GetAxisX();
    const FVector Yu = Qu.GetAxisY();
    const FVector Zu = Qu.GetAxisZ();

    FMatrix Mu = FMatrix::Identity;
    Mu.SetAxes(&Xu, &Yu, &Zu);

    const FMatrix B = BuildUnityToUEBasis(YawDeg);
    const FMatrix BT = B.GetTransposed();
    const FMatrix Me = B * Mu * BT;

    FQuat Qe(Me);
    Qe.Normalize();
    return Qe;
}

// ---------------- OSC message handler ----------------

void FVMCLiveLinkSource::OnOscMessageReceived(const FOSCMessage& Msg, const FString& FromIP, uint16 FromPort)
{
    const FString Addr = Msg.GetAddress().GetFullPath();

    if (Addr == TEXT("/VMC/Ext/Bone/Pos"))
    {
        FString Bone; float px, py, pz, qx, qy, qz, qw;
        if (!ReadStringFloat7(Msg, Bone, px, py, pz, qx, qy, qz, qw))
            return;

        const FName BoneName(*Bone);

        FVector P = bUnityToUE ? MapPos_UnityToUE(FVector(px, py, pz), bMetersToCm, YawOffsetDeg)
            : FVector(px, py, pz);
        FQuat   Q = bUnityToUE ? ConvertQuat_UnityToUE(FQuat(qx, qy, qz, qw), YawOffsetDeg)
            : FQuat(qx, qy, qz, qw);

        const FTransform Xf(Q, P, FVector(1));

        FScopeLock Lock(&DataGuard);
        if (!BoneNames.Contains(BoneName))
        {
            // Default: first seen bone becomes root (-1 parent). Others parent to 0 unless explicitly "root".
            int32 Parent = BoneNames.Num() == 0 ? -1 : 0;
            if (BoneName == FName("root")) Parent = -1;
            BoneNames.Add(BoneName);
            BoneParents.Add(Parent);
        }
        PendingPose.Add(BoneName, Xf);
    }
    else if (Addr == TEXT("/VMC/Ext/Root/Pos"))
    {
        float px, py, pz, qx, qy, qz, qw;
        if (!ReadFloat7(Msg, px, py, pz, qx, qy, qz, qw))
            return;

        FVector PR = bUnityToUE ? MapPos_UnityToUE(FVector(px, py, pz), bMetersToCm, YawOffsetDeg)
            : FVector(px, py, pz);
        FQuat   QR = bUnityToUE ? ConvertQuat_UnityToUE(FQuat(qx, qy, qz, qw), YawOffsetDeg)
            : FQuat(qx, qy, qz, qw);

        {
            FScopeLock Lock(&DataGuard);
            PendingRoot = FTransform(QR, PR, FVector(1));

            // Ensure a 'root' exists in the skeleton so we have a slot to apply it
            if (!BoneNames.Contains(FName("root")))
            {
                BoneNames.Insert(FName("root"), 0);
                BoneParents.Insert(-1, 0);
            }
        }
    }
    else if (Addr == TEXT("/VMC/Ext/Blend/Val"))
    {
        const TArray<UE::OSC::FOSCData>& A = Msg.GetArgumentsChecked();
        if (A.Num() != 2) return;

        const FName CurveName(*A[0].GetString());
        const float Val = A[1].GetFloat();

        FScopeLock Lock(&DataGuard);
        if (!CurveNameToIndex.Contains(CurveName))
        {
            const int32 NewIdx = CurveNamesOrdered.Add(CurveName);
            CurveNameToIndex.Add(CurveName, NewIdx);
            bStaticCurvesDirty = true; // advertise this name in static data
        }
        PendingCurves.Add(CurveName, Val);
    }
    else if (Addr == TEXT("/VMC/Ext/Blend/Apply"))
    {
        PushStaticData(/*bForce=*/false);
        PushFrame();

        FScopeLock Lock(&DataGuard);
        PendingCurves.Reset();

        if (bStaticCurvesDirty)
        {
            bStaticCurvesDirty = false;
            PushStaticData(/*bForce=*/true);
        }
    }
}

// ---------------- Live Link data push ----------------

void FVMCLiveLinkSource::PushStaticData(bool bForce)
{
    FScopeLock Lock(&DataGuard);

    const bool bHaveBones = BoneNames.Num() > 0;
    if (!Client || (!bForce && (bStaticSent || !bHaveBones)))
    {
        return;
    }

    FLiveLinkStaticDataStruct StaticData(FLiveLinkSkeletonStaticData::StaticStruct());
    auto& Skel = *StaticData.Cast<FLiveLinkSkeletonStaticData>();

    Skel.SetBoneNames(BoneNames);
    Skel.SetBoneParents(BoneParents);

    // UE 5.6: curves are "properties"
    Skel.PropertyNames = CurveNamesOrdered;

    Client->PushSubjectStaticData_AnyThread({ SourceGuid, SubjectName },
        ULiveLinkAnimationRole::StaticClass(), MoveTemp(StaticData));

    bStaticSent = true;
}

void FVMCLiveLinkSource::PushFrame()
{
    FScopeLock Lock(&DataGuard);
    if (!Client || !bStaticSent)
    {
        return;
    }

    FLiveLinkFrameDataStruct Frame(FLiveLinkAnimationFrameData::StaticStruct());
    auto& Anim = *Frame.Cast<FLiveLinkAnimationFrameData>();

    // Bones
    const int32 NumBones = BoneNames.Num();
    Anim.Transforms.SetNum(NumBones);

    for (int32 i = 0; i < NumBones; ++i)
    {
        const FName B = BoneNames[i];
        if (const FTransform* T = PendingPose.Find(B))
        {
            Anim.Transforms[i] = *T;
        }
        else
        {
            Anim.Transforms[i] = FTransform::Identity;
        }
    }

    // Apply root motion by NAME (more robust than "index 0")
    const int32 RootIdx = BoneNames.IndexOfByKey(FName("root"));
    if (RootIdx != INDEX_NONE)
    {
        Anim.Transforms[RootIdx] = PendingRoot;
    }

    // Properties
    FLiveLinkBaseFrameData& Base = static_cast<FLiveLinkBaseFrameData&>(Anim);
    const int32 NumProps = CurveNamesOrdered.Num();
    Base.PropertyValues.SetNum(NumProps);
    for (int32 i = 0; i < NumProps; ++i) Base.PropertyValues[i] = 0.0f;

    for (const TPair<FName, float>& KV : PendingCurves)
    {
        if (const int32* Idx = CurveNameToIndex.Find(KV.Key))
        {
            if (Base.PropertyValues.IsValidIndex(*Idx))
            {
                Base.PropertyValues[*Idx] = KV.Value;
            }
        }
    }

    Client->PushSubjectFrameData_AnyThread({ SourceGuid, SubjectName }, MoveTemp(Frame));
}
