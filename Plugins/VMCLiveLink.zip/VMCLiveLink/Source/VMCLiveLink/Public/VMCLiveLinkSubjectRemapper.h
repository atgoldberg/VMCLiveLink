﻿#pragma once

#include "CoreMinimal.h"
#include "LiveLinkSubjectRemapper.h"
#include "Roles/LiveLinkAnimationRole.h"
#include "Roles/LiveLinkAnimationTypes.h"
#include "VMCLiveLinkSubjectRemapper.generated.h"

UCLASS(EditInlineNew, BlueprintType)
class VMCLIVELINK_API UVMCLiveLinkSubjectRemapper : public ULiveLinkSubjectRemapper
{
	GENERATED_BODY()

public:
	virtual TSubclassOf<ULiveLinkRole> GetSupportedRole() const override
	{
		return ULiveLinkAnimationRole::StaticClass();
	}

	// NOTE: not const in UE 5.6
	virtual FWorkerSharedPtr CreateWorker() override;

	UFUNCTION(CallInEditor, Category = "VMC|Remap")
	void SeedCommonMappings();
};
