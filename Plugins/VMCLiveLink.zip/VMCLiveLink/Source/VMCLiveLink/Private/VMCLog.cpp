#include "VMCLog.h"
DEFINE_LOG_CATEGORY(LogVMCLiveLink);
