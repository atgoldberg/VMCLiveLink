﻿#pragma once

#include "CoreMinimal.h"
#include "LiveLinkFrameTranslator.h"
#include "Roles/LiveLinkAnimationRole.h"
#include "VMCAxisUnitsTranslator.generated.h"

UCLASS(EditInlineNew, BlueprintType)
class VMCLIVELINK_API UVMCAxisUnitsTranslator : public ULiveLinkFrameTranslator
{
	GENERATED_BODY()

public:
	virtual TSubclassOf<ULiveLinkRole> GetFromRole() const override { return ULiveLinkAnimationRole::StaticClass(); }
	virtual TSubclassOf<ULiveLinkRole> GetToRole()   const override { return ULiveLinkAnimationRole::StaticClass(); }

	// NOTE: must use the qualified typedef for the override to bind.
	virtual ULiveLinkFrameTranslator::FWorkerSharedPtr CreateWorker(TSubclassOf<ULiveLinkRole> InRole) const override;

public:
	UPROPERTY(EditAnywhere, Category = "VMC|Units")
	float UnitsScale = 1.0f;

	/** Rotate Unity +Z forward to UE +X forward (i.e., +90° around +Z). */
	UPROPERTY(EditAnywhere, Category = "VMC|Axes")
	bool bRotateUnityForwardToUE = true;

	/** Optional mirror across Y to fix handedness, if needed. */
	UPROPERTY(EditAnywhere, Category = "VMC|Axes")
	bool bMirrorY = false;
};
